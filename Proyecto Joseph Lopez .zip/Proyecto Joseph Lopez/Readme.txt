Análisis Redes Sociales

En el siguiente proyecto se encuentran funciones las cuales cumplen con una interfaz que:

1. Permite cargar un archivo txt de usuarios.
2. Permite mostrar un grafo de los usuarios cargados en cuestión.
3. Permite mostrar la Conexión de los usuarios Fuertemente Conectados.
4. Permite agregar/eliminar un usuario en cuestión.